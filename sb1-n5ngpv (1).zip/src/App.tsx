import React, { useEffect, useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import BeerSection from './components/BeerSection';
import About from './components/About';
import Contact from './components/Contact';
import Footer from './components/Footer';
import ParallaxSection from './components/ParallaxSection';
import BeerFoam from './components/BeerFoam';

function App() {
  const [bubbles, setBubbles] = useState<
    { id: number; left: string; delay: number; size: number }[]
  >([]);

  useEffect(() => {
    const newBubbles = Array.from({ length: 30 }, (_, i) => ({
      id: i,
      left: `${Math.random() * 100}%`,
      delay: Math.random() * 5,
      size: Math.random() * 30 + 10,
    }));
    setBubbles(newBubbles);
  }, []);

  return (
    <div className="relative bg-[#162a79] overflow-hidden">
      <BeerFoam />
      {/* Bubbles */}
      {bubbles.map((bubble) => (
        <div
          key={bubble.id}
          className="bubble"
          style={{
            left: bubble.left,
            width: `${bubble.size}px`,
            height: `${bubble.size}px`,
            animationDelay: `${bubble.delay}s`,
            animationDuration: `${5 + Math.random() * 5}s`,
          }}
        />
      ))}

      {/* Main Content */}
      <Navbar />
      <Hero />
      <ParallaxSection 
        imageUrl="https://signaturedistributors.co.uk/wp-content/uploads/2024/11/51a5ac42-72de-4fec-a83d-46a8e815ad8e.png"
        title="Crafted for Excellence"
        description="Every drop tells a story of precision, passion, and perfection"
      />
      <BeerSection />
      <ParallaxSection 
        imageUrl="https://signaturedistributors.co.uk/wp-content/uploads/2024/10/blur-beer.png"
        title="Heritage Meets Innovation"
        description="Blending traditional brewing methods with modern sophistication"
      />
      <About />
      <Contact />
      <Footer />
    </div>
  );
}

export default App;