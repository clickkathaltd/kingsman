import React, { useEffect, useState } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { Crown } from 'lucide-react';

const Hero = () => {
  const { scrollYProgress } = useScroll();
  const opacity = useTransform(scrollYProgress, [0, 0.3], [1, 0]);
  const scale = useTransform(scrollYProgress, [0, 0.3], [1, 0.8]);
  const [bubbles, setBubbles] = useState<
    { id: number; left: string; delay: number; size: number }[]
  >([]);

  useEffect(() => {
    const newBubbles = Array.from({ length: 20 }, (_, i) => ({
      id: i,
      left: `${Math.random() * 100}%`,
      delay: Math.random() * 5,
      size: Math.random() * 30 + 10,
    }));
    setBubbles(newBubbles);
  }, []);

  return (
    <section
      id="home"
      className="h-screen relative overflow-hidden bg-cover bg-center"
      style={{
        backgroundImage: `url('https://www.kingsmanbeer.com/images/welcome-img.png')`,
      }}
    >
      {/* Bubbles */}
      {bubbles.map((bubble) => (
        <div
          key={bubble.id}
          className="bubble"
          style={{
            left: bubble.left,
            width: `${bubble.size}px`,
            height: `${bubble.size}px`,
            animationDelay: `${bubble.delay}s`,
            animationDuration: `${5 + Math.random() * 5}s`,
          }}
        />
      ))}

      {/* Content */}
      <div className="relative h-full flex items-center justify-center text-white bg-[#162a79]/50">
        <motion.div style={{ scale, opacity }} className="text-center px-4">
          <motion.div
            initial={{ y: -50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 1 }}
            className="flex justify-center mb-6"
          >
            <motion.div
              animate={{
                rotate: [0, -10, 10, -10, 10, 0],
              }}
              transition={{
                repeat: Infinity,
                repeatDelay: 2,
                duration: 0.5,
              }}
            >
              <Crown size={64} className="text-amber-400" />
            </motion.div>
          </motion.div>
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="text-6xl md:text-8xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-b from-amber-400 to-amber-600"
          >
            KINGSMAN BEER
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.4 }}
            className="text-xl md:text-2xl mb-8"
          >
            Crafted for Gentlemen, Enjoyed by Kings
          </motion.p>
          <motion.button
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.6 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="bg-gradient-to-r from-amber-400 to-amber-600 text-black px-8 py-3 rounded-full text-lg font-semibold hover:from-amber-500 hover:to-amber-700 transition-all duration-300 transform hover:-translate-y-1"
          >
            Discover Our Legacy
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;