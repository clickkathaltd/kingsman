import React from "react";
import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";

const beers = [
  {
    name: "Royal Lager",
    description: "A premium lager fit for kings",
    video: "https://signaturedistributors.co.uk/wp-content/uploads/2024/11/Untitled-design-5.mp4",
  },
  {
    name: "Gentleman's Ale",
    description: "Traditional English-style ale",
    video: "https://signaturedistributors.co.uk/wp-content/uploads/2024/11/Untitled-design-6.mp4",
  },
];

const BeerSection = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  return (
    <section id="beers" className="py-20 flow-section">
      <div className="container mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-5xl font-bold text-center mb-16 bg-clip-text text-transparent bg-gradient-to-r from-amber-400 to-amber-600"
        >
          Our Distinguished Collection
        </motion.h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
          {beers.map((beer, index) => (
            <motion.div
              key={beer.name}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              className="relative group"
            >
              <div className="beer-foam absolute -top-8 left-0 right-0" />
              <motion.div
                whileHover={{ scale: 1.05 }}
                transition={{ duration: 0.3 }}
                className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-[#1e367e] to-[#162a79]"
              >
                <div className="p-8">
                  <div className="relative mx-auto" style={{ width: '600px', maxWidth: '100%' }}>
                    <div style={{ paddingBottom: '166.67%' }} className="relative">
                      <video
                        autoPlay
                        loop
                        muted
                        playsInline
                        className="absolute inset-0 w-full h-full object-cover rounded-xl"
                      >
                        <source src={beer.video} type="video/mp4" />
                        Your browser does not support the video tag.
                      </video>
                    </div>
                  </div>
                  <div className="mt-6 text-center">
                    <h3 className="text-3xl font-bold text-amber-400 mb-2">
                      {beer.name}
                    </h3>
                    <p className="text-gray-300">{beer.description}</p>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BeerSection;