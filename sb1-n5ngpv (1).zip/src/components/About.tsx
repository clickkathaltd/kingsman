import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';

const About = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  return (
    <section id="about" className="py-20 bg-transparent">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <motion.div
            ref={ref}
            initial={{ opacity: 0, x: -50 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl font-bold text-white mb-6">Our Legacy</h2>
            <p className="text-white text-lg leading-relaxed">
              More than 335 years ago, Jean de Chaine from Wallonia founded a brewpub in Mannheim which he named after the germanised version of his family name: Eichbaum. This has become one of the largest and most efficient breweries in Baden-Württemberg. It is the oldest company in Mannheim but also one of the most modern, with state-of-the-art bottling and brewing technologies and an annual output of 1.8 mn hl. More than 16 different beers and a huge number of trading units make Privatbrauerei Eichbaum an attractive partner.
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="mt-8 bg-amber-500 text-black px-8 py-3 rounded-full text-lg font-semibold hover:bg-amber-400 transition-colors"
            >
              Learn More
            </motion.button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <img
              src="https://signaturedistributors.co.uk/wp-content/uploads/2024/10/Kingsman-products.png"
              alt="Brewery"
              className="rounded-lg shadow-2xl"
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default About;
