import React from 'react';
import { motion } from 'framer-motion';
import { Facebook, Instagram, Twitter, Youtube } from 'lucide-react';

const socialLinks = [
  { icon: Facebook, url: 'https://www.facebook.com/KingsmanBeerPremiumGermanLager' },
  { icon: Instagram, url: 'https://www.instagram.com/kingsmanbeer' },
  { icon: Twitter, url: 'https://twitter.com/kingsmanbeer' },
  { icon: Youtube, url: 'https://www.youtube.com/@kingsmanbeer' }
];

const Footer = () => {
  return (
    <footer className="bg-[#0a1435] text-white py-12">
      <div className="container mx-auto px-4">
        <div className="flex flex-col items-center space-y-8">
          <motion.div 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.8 }}
            className="flex space-x-6"
          >
            {socialLinks.map((social, index) => (
              <motion.a
                key={index}
                href={social.url}
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ scale: 1.2, color: '#fcd34d' }}
                className="text-white hover:text-amber-300 transition-colors"
              >
                <social.icon size={24} />
              </motion.a>
            ))}
          </motion.div>
          <div className="text-center">
            <p className="text-gray-400">© {new Date().getFullYear()} Kingsman Beer. All rights reserved.</p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;