import React from 'react';
import { motion } from 'framer-motion';

const BeerFoam = () => {
  return (
    <div className="fixed left-0 top-0 h-full w-32 pointer-events-none z-0">
      <div className="relative h-full">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-full"
            initial={{ y: "-100%", opacity: 0 }}
            animate={{ 
              y: "100%", 
              opacity: [0, 1, 1, 0],
            }}
            transition={{
              duration: 8,
              repeat: Infinity,
              delay: i * 0.4,
              ease: "linear"
            }}
          >
            <div className="beer-foam-bubble" 
              style={{
                left: `${Math.random() * 100}%`,
                width: `${Math.random() * 20 + 10}px`,
                height: `${Math.random() * 20 + 10}px`,
              }}
            />
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default BeerFoam;