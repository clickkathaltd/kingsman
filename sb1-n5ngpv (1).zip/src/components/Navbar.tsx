import React from 'react';
import { Menu } from 'lucide-react';

const Navbar = () => {
  return (
    <nav className="fixed w-full z-50 bg-[#162a79]/90 text-white">
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          {/* Replace text with logo */}
          <a href="#home" className="flex items-center">
            <img 
              src="https://www.kingsmanbeer.com/images/logo/kingsman-footer-logo.png" 
              alt="Kingsman Logo" 
              className="h-8" // Adjust height as needed
            />
          </a>
          <div className="hidden md:flex space-x-8">
            <a href="#home" className="hover:text-amber-400 transition-colors">Home</a>
            <a href="#beers" className="hover:text-amber-400 transition-colors">Our Beers</a>
            <a href="#about" className="hover:text-amber-400 transition-colors">About Us</a>
            <a href="#contact" className="hover:text-amber-400 transition-colors">Contact</a>
          </div>
          <button className="md:hidden">
            <Menu size={24} />
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
